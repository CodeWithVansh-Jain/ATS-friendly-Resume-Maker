using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace resume_maker.Models
{
    public class ResumeModel
    {
        [Required]
        public string FullName { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required, Phone]
        public string Phone { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public string Skills { get; set; }

        public string Experience { get; set; }

        [Required]
        public string Education { get; set; }

        public IFormFile ProfileImage { get; set; }
    }
}