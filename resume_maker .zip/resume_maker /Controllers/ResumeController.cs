using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using resume_maker.Models;
using System;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace resume_maker.Controllers
{
    public class ResumeController : Controller
    {
        private readonly IConfiguration _configuration;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public ResumeController(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
        {
            _configuration = configuration;
            _webHostEnvironment = webHostEnvironment;
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Submit(ResumeModel model)
        {
            if (!ModelState.IsValid)
            {
                return View("Create", model);
            }

            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            string profileImagePath = null;

            // Handling file upload
            if (model.ProfileImage != null && model.ProfileImage.Length > 0)
            {
                string uploadDir = Path.Combine(_webHostEnvironment.WebRootPath, "uploads");
                Directory.CreateDirectory(uploadDir);
                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(model.ProfileImage.FileName);
                string filePath = Path.Combine(uploadDir, fileName);
                
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await model.ProfileImage.CopyToAsync(fileStream);
                }

                profileImagePath = "/uploads/" + fileName;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Resumes (FullName, Email, Phone, Address, Skills, Experience, Education, ProfileImagePath) 
                                 VALUES (@FullName, @Email, @Phone, @Address, @Skills, @Experience, @Education, @ProfileImagePath)";
                
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@FullName", model.FullName);
                    cmd.Parameters.AddWithValue("@Email", model.Email);
                    cmd.Parameters.AddWithValue("@Phone", model.Phone);
                    cmd.Parameters.AddWithValue("@Address", model.Address);
                    cmd.Parameters.AddWithValue("@Skills", model.Skills);
                    cmd.Parameters.AddWithValue("@Experience", model.Experience ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@Education", model.Education);
                    cmd.Parameters.AddWithValue("@ProfileImagePath", profileImagePath ?? (object)DBNull.Value);

                    await conn.OpenAsync();
                    await cmd.ExecuteNonQueryAsync();
                }
            }

            TempData["SuccessMessage"] = "Resume submitted successfully!";
            return RedirectToAction("Create");
        }
    }
}
